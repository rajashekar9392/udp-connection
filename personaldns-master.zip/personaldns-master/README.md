# personaldns

Managing Personal Ipv6 Addresses by on demand fetching and storing it in DNS hosts File or cloud.

## Goal

IPv6 Addresses are Global which gives it all powers as Public IPv4 Addresses
Downside being it gives potential hackers greater chance to Comprimise device
(cause private ipv4s are behind NAT and also NATS Filter Inbound Traffic)
Goal of this project is to utilize the benefits of IPv6 and also remaining Ghost
That can be done efficiently by personal dns on personal cloud or drive or ftp
without exposing IPv6 Addresses publicly and completely priceless.

## Progress

Extracting IPv6 Addresses and swapping DNS hosts Files. Generate output file and
Swap in latest ipv6 addresses from output file to DNS Hosts File

## Built With

* [Java]

## Usage

>>java -jar hostsip.jar



Ex:  java hostsip -N tarun -H laptop

Ex:  java hostsip -f config.txt 

Ex:  java hostsip -o config.txt 

Domain name will be laptop.tarun.project 

Run File as root/Administrator

## Author

* **Tarun Koyalwar**   - [tarunKoyalwar](https://github.com/tarunKoyalwar)
