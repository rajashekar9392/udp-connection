package ipv6adds;

import java.util.*;


import java.io.BufferedWriter;
import java.io.File;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class hostsip {
	private static ArrayList<Inet6Address> ias = new ArrayList<>(10);
	private static String username = null;
	private static String  host_type = null;
	private static List<String> lines =null;
	private static String hosts_path = null;
	private static String config_file = null;
	private static String output_file = null;
	
	private static void cmdoptions() {
		System.out.println("Please Mention Arguments");
		System.out.println("-N   name_of_user");
		System.out.println("-H   type_of_host");
		System.out.println("-f  file_name  copies ips from file");
		System.out.println("-o  outputs ipv6 addresses");
		System.out.println("");
		System.out.println("Ex:  java hostsip -N tarun -H laptop\n");
		System.out.println("Ex:  java hostsip -f config.txt \n");
		System.out.println("Ex:  java hostsip -o output.txt \n");
		System.out.println("Domain name will be laptop.tarun.project ");
		System.out.println("\n Run File as root/Administrator");
	}
	
	private static void open_and_filter(String filepath) throws Exception{
		lines = Files.readAllLines(Paths.get(filepath));
		System.out.println("File found removing older entries");
		ArrayList<Integer> removeold = new ArrayList<>(4);
		for(int i=0;i<lines.size();i++) {
			if(lines.get(i).contains("# "+username+" "+host_type)) {
				removeold.add(i);
			}
		}
		if(removeold.size()<1) {
			return;
		}
		System.out.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
		for(int i=0;i<=removeold.get(1)-removeold.get(0);i++) {
			String zx =lines.remove(removeold.get(0)+0);
			System.out.println("removed : "+zx);
		}
		System.out.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
//		lines.forEach(z -> System.out.println(z));
		
		File x = new File(hosts_path);
		File backup = new File(hosts_path+".bk");
		System.out.println("Creating File backup");
		x.renameTo(backup);
		
	}
	
	private static void configfile(String filename) throws Exception{
		List<String> lines2 = Files.readAllLines(Paths.get(filename));
		int total_lines = lines2.size();
		System.out.println("total lines "+total_lines);
		int i=0;
		while(i++<total_lines-1) {
			if(lines2.get(i).contains("laptop") || lines2.get(i).contains("mobile")) {
				if(lines.contains(lines2.get(i))) {
					int index = lines.indexOf(lines2.get(i));
					lines.remove(index);
					lines.remove(index);
					lines.remove(index);
					i+=2;
				}
			}
		}
		
		lines2.forEach(z -> lines.add(z));
		return;
	}
	
	private static void out_file() throws Exception{
		int indexis=0;
		for(String z:lines) {
			if(z.contains("laptop") || z.contains("mobile")) {
				indexis = lines.indexOf(z);
				break;
			}
		}
		for(int j=0;j<indexis-2;j++) {
			lines.remove(0);
		}
		File ipads = Paths.get(System.getProperty("user.home"),output_file).toFile();
		System.out.println("File will be saved at : "+ipads.getCanonicalPath());
		add_entries(ipads.getCanonicalPath());
	}
	
	private static void add_entries(String filepath) throws Exception{
	       try(BufferedWriter writer = Files.newBufferedWriter(new File(filepath).toPath())){
	    	   for(String line:lines) {
	    		   writer.write(line);
	    		   writer.newLine();
	    	   }
	    	   writer.newLine();
	    	   if(ias.size()>=1) {
	    		   writer.newLine();
		    	   writer.newLine();
		    	   writer.write("# "+username+" "+host_type);
		    	   writer.newLine();
		    	   for(Inet6Address i6 :ias) {
		    		   String ip = i6.toString();
		    		   ip=ip.replace("/", "");
		    		   ip=ip.replace(ip.substring(ip.indexOf("%")),"");
		    		   String entry = ip+"   "+host_type+"."+username+".project";
		    		   writer.write(entry);
		    		   writer.newLine();
		    		   System.out.println("added : "+entry); 
		    		   break;
		    	   }
		    	   writer.write("# "+username+" "+host_type);
		    	   writer.newLine();
	    	   }
	       }
	}
	
	private static void get_ipv6_addresses() throws Exception{
		 ArrayList<NetworkInterface> nfs = Collections.list(NetworkInterface.getNetworkInterfaces());		
		 for(NetworkInterface z:nfs) {
	        	ArrayList<InetAddress> ia = Collections.list(z.getInetAddresses());
//	        	System.out.println(ia.size());
	        	for(InetAddress zs:ia) {
	        		if(zs instanceof Inet6Address) {
	        			if(!zs.isLinkLocalAddress() && !zs.isLoopbackAddress()) {
	        				System.out.println("* Global ipv6 found "+zs.getHostAddress());
		        			ias.add((Inet6Address) zs);
	        			}
	        		}
	        	}
		 }
	}
	
	public static void main(String[] args) throws Exception {
		
		//check if windows or linux
		String x = System.getProperty("os.name");
		if(x.equalsIgnoreCase("Linux")) {
		    hosts_path = "/etc/hosts";
		}else {
			hosts_path = "c:\\Windows\\System32\\Drivers\\etc\\hosts";
		}
		
		
		if(args.length < 1 || args.length >4) {
			hostsip.cmdoptions();
			return;
		}else if(args.length == 2) {
			if(args[0].equalsIgnoreCase("-f")) {
				config_file = args[1];
				open_and_filter(hosts_path);
				configfile(config_file);
				add_entries(hosts_path);
				return;
			}else if(args[0].equalsIgnoreCase("-o")) {
				output_file = args[1];
				open_and_filter(hosts_path);
				out_file();
				return;
			}
		}else if(args.length == 4){
			if(args[0].equalsIgnoreCase("-N") && args[2].equalsIgnoreCase("-H")) {
				username = args[1];
				host_type = args[3];
				open_and_filter(hosts_path);
				get_ipv6_addresses();
				add_entries(hosts_path);
				return;
				
			}else {
				System.out.println("poor choice");
				hostsip.cmdoptions();
				return;
			}
		}
		
	    
	}

}
